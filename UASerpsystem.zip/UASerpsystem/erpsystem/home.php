<center><br><br><br><br><br><br><br><br>
<img src="assets/images/dayistic_logo.jpg" width="400px height="400px" /> <br>
<font Size="6" face="Helvetica">Welcome To Dayistic</font> <br>
<font Size="3">For Gamers by Gamers</font>
</center>
